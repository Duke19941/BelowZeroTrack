# Changelog

## 0.3.0-1.30exp

Bug fixes
- Marks are no longer left behind as untracked orphans after a server restart.
- Evicting the oldest mark now removes the oldest (`RemoveOrdered`, not `Remove`).
- `maxMarks` of 0 no longer crashes; settings are clamped and logged.
- Ground snap now uses `SurfaceY` (height). `SurfaceGetType` returns a surface name, not a height.
- Kicking snow over a nearly-gone mark no longer extends its life.
- "Rain does nothing" now holds: the overcast term is skipped while raining.

Performance and stability
- 1 s tick uses `Timer` instead of `CallLater`, which drifts after ~4.5 h uptime.
- No per-tick allocations (player list and movement state are reused).
- Per-player trail state moved onto `PlayerBase`, so nothing leaks on disconnect or death.
- Client rebuilds particles only when the stage or kicked state changes.
- Sync variables have bounds; `m_Kicked` is a bool.

Behaviour
- Blood particle stops at the frost stage.
- Marks can no longer be picked up via "Take" actions.
- Trail resets after bleeding stops, swimming or vehicle use.

Config and docs
- `BelowZeroTrack_Data` added to the Scripts `requiredAddons` for load order.
- Removed the client-side `MissionGameplay` print-only override.
- README documents install and every setting. JSON keys are unchanged from 0.2.0.
