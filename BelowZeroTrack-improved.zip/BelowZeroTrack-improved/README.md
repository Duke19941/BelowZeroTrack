# BELOWZERO Crimson Rime 0.3.0-1.30exp

Hardcore blood trail for **BELOWZERO** on **DayZ 1.30 Experimental**.

Bleeding players leave blood marks on the snow. Marks go through three stages
(steaming, glazed, frosted) and then vanish. Wind and snowfall bury them faster.
Rain does nothing. Motorbikes and vehicles do not write marks.

Players can **read** a mark (freshness and how hard the person was bleeding) or
**kick snow over it** (shortens its life, leaves a scuff).

## Install

1. Pack `Data` and `Scripts` with DayZ Tools (see `Tools/pack_notes.txt`).
2. Load `@BelowZeroTrack` on the server and clients. Do not load `@SoftTrack` with it.
3. First server start writes `$profile:BelowZeroTrack/settings.json`.

## Settings

Edit `settings.json`, then restart. Missing keys use defaults. Out-of-range values
are clamped in memory and logged. The file is never rewritten after first creation.
`Mission/settings.example.json` shows every key.

| Key | Default | Range | Meaning |
|---|---|---|---|
| `enabled` | true | | Master switch for new marks. Existing marks still fade. |
| `dropSeconds` | 3.2 | 0.5-60 | Minimum time between marks per player (ticks are 1 s). |
| `lifetimeSeconds` | 900 | 30-86400 | Life of a mark in calm weather. |
| `minDistance` | 1.6 | 0.5-20 | Metres moved before the next mark. |
| `windMultiplier` | 2.8 | 0-20 | Extra aging at full wind. |
| `overcastThreshold` | 0.55 | 0-1 | Overcast level where the storm term starts. Ignored while raining. |
| `stormMultiplier` | 2.2 | 0-20 | Extra aging from overcast and snowfall. |
| `blizzardMul` | 1.0 | 0.1-10 | Base aging rate. |
| `maxMarks` | 80 | 1-1000 | Server-wide cap. Oldest marks are removed first. |

## Compatibility

The mod adds `BZ_`-prefixed fields and methods to `PlayerBase` and overrides no
vanilla methods. It also modifies `MissionServer` and `ActionConstructor`. Test
alongside Syberia, Med Plus and Terje before going live.

See `CHANGELOG.md` for what changed in 0.3.0.
