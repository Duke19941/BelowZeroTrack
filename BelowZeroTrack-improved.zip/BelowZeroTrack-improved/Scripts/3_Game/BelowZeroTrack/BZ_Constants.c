class BZ_Constants
{
    static const string LOG_PREFIX    = "[BELOWZERO Crimson Rime] ";
    static const string PROFILE_DIR   = "$profile:BelowZeroTrack";
    static const string SETTINGS_PATH = "$profile:BelowZeroTrack/settings.json";
    static const string MARK_CLASS    = "BZ_Spoor";
    static const string SOUND_HOT     = "BZ_SpoorHot_SoundSet";
    static const string SERVER_NAME   = "BELOWZERO";

    // Settings defaults (mirrored in Mission/settings.example.json)
    static const float DEFAULT_DROP_SEC      = 3.2;
    static const float DEFAULT_LIFE_SEC      = 900.0;
    static const float DEFAULT_MIN_DIST      = 1.6;
    static const float DEFAULT_WIND_MUL      = 2.8;
    static const float DEFAULT_OVERCAST_T    = 0.55;
    static const float DEFAULT_STORM_MUL     = 2.2;
    static const float DEFAULT_BLIZZARD_MUL  = 1.0;
    static const int   DEFAULT_MAX_MARKS     = 80;

    // Timing
    static const float TICK_SEC        = 1.0;
    static const int   ORPHAN_CHECK_MS = 5000;

    // Weather aging
    static const float WIND_FULL_SPEED   = 20.0;
    static const float WIND_CLAMP_MAX    = 1.5;
    static const float RAIN_IGNORE_ABOVE = 0.05;
    static const float SNOW_MIN          = 0.08;
    static const float SNOW_WEIGHT       = 1.4;

    // Mark behaviour
    static const float HOT_RATIO           = 0.62;
    static const float GLAZE_RATIO         = 0.28;
    static const float KICK_LIFE_RATIO     = 0.22;
    static const float WEIGHT2_HEALTH      = 60.0;
    static const float WEIGHT3_HEALTH      = 35.0;
    static const float SPRINT_SPACING_MUL  = 1.55;
    static const float CROUCH_SPACING_MUL  = 0.65;
    static const float SPRINT_SPEED        = 5.8;
    static const float GROUND_SNAP_MAX     = 0.6;

    static const int STAGE_GONE  = 0;
    static const int STAGE_HOT   = 1;
    static const int STAGE_GLAZE = 2;
    static const int STAGE_RIME  = 3;
};
