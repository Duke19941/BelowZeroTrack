class BZ_Manager
{
    protected static ref BZ_Manager s_Instance;

    protected ref array<BZ_Spoor> m_Marks;
    protected ref array<Man> m_PlayerBuf;   // reused every tick, never reallocated
    protected ref Timer m_Timer;
    protected bool m_Started;

    static BZ_Manager Get()
    {
        if (!s_Instance)
            s_Instance = new BZ_Manager();
        return s_Instance;
    }

    void BZ_Manager()
    {
        m_Marks = new array<BZ_Spoor>;
        m_PlayerBuf = new array<Man>;
    }

    void Start()
    {
        if (m_Started)
            return;
        m_Started = true;

        // Timer instead of CallLater(..., true): CallLater loses precision after ~4.5h uptime
        m_Timer = new Timer(CALL_CATEGORY_GAMEPLAY);
        m_Timer.Run(BZ_Constants.TICK_SEC, this, "Tick", null, true);
    }

    void Tick()
    {
        if (!GetGame() || !GetGame().IsServer())
            return;

        BZ_Settings settings = BZ_Config.Get();

        // Aging always runs, so disabling the mod lets existing marks fade out
        if (settings.enabled)
            DropFromBleeders(settings);
        AgeMarks(WeatherMul(settings));
    }

    protected float WeatherMul(BZ_Settings settings)
    {
        float mul = settings.blizzardMul;
        Weather weather = GetGame().GetWeather();
        if (!weather)
            return mul;

        float wind = 0;
        if (weather.GetWindMagnitude())
            wind = weather.GetWindMagnitude().GetActual();
        else
            wind = weather.GetWind().Length();
        float wind01 = Math.Clamp(wind / BZ_Constants.WIND_FULL_SPEED, 0.0, BZ_Constants.WIND_CLAMP_MAX);
        mul = mul + (settings.windMultiplier * wind01);

        // Rain does nothing: the overcast term is skipped while it is raining
        float rain = 0;
        if (weather.GetRain())
            rain = weather.GetRain().GetActual();

        float overcast = 0;
        if (weather.GetOvercast())
            overcast = weather.GetOvercast().GetActual();
        if (rain <= BZ_Constants.RAIN_IGNORE_ABOVE && overcast >= settings.overcastThreshold)
            mul = mul + (settings.stormMultiplier * overcast);

        float snow = 0;
        if (weather.GetSnowfall())
            snow = weather.GetSnowfall().GetActual();
        if (snow > BZ_Constants.SNOW_MIN)
            mul = mul + (settings.stormMultiplier * snow * BZ_Constants.SNOW_WEIGHT);

        return mul;
    }

    protected void DropFromBleeders(BZ_Settings settings)
    {
        m_PlayerBuf.Clear();
        GetGame().GetPlayers(m_PlayerBuf);

        for (int i = 0; i < m_PlayerBuf.Count(); i++)
        {
            PlayerBase pb = PlayerBase.Cast(m_PlayerBuf.Get(i));
            if (!pb)
                continue;

            if (!pb.IsAlive() || !pb.IsBleeding() || pb.IsSwimming() || pb.BZ_IsInTransport())
            {
                // Break the trail so the next mark does not aim at a stale position
                pb.BZ_ClearTrail();
                continue;
            }

            float cd = pb.BZ_GetCooldown() - BZ_Constants.TICK_SEC;
            if (cd > 0)
            {
                pb.BZ_SetCooldown(cd);
                continue;
            }
            pb.BZ_SetCooldown(0);

            vector pos = pb.GetPosition();
            float need = settings.minDistance * pb.BZ_TrackSpacingMul();
            if (pb.BZ_IsSprinting())
                need = settings.minDistance * BZ_Constants.SPRINT_SPACING_MUL;

            float yaw = pb.GetOrientation()[0];
            if (pb.BZ_HasLastPos())
            {
                vector last = pb.BZ_GetLastPos();
                if (vector.Distance(pos, last) < need)
                    continue;
                vector dir = pos - last;
                if (dir.Length() > 0.2)
                    yaw = dir.VectorToAngles()[0];
            }

            float health = pb.GetHealth("", "Health");
            int weight = 1;
            if (health < BZ_Constants.WEIGHT2_HEALTH)
                weight = 2;
            if (health < BZ_Constants.WEIGHT3_HEALTH)
                weight = 3;

            SpawnMark(pos, settings, weight, yaw);
            pb.BZ_SetLastPos(pos);

            float drop = settings.dropSeconds;
            if (weight >= 3)
                drop = drop * 0.7;
            pb.BZ_SetCooldown(drop);
        }
    }

    protected void SpawnMark(vector pos, BZ_Settings settings, int weight, float yaw)
    {
        if (pos == vector.Zero)
            return;
        pos = SnapToGround(pos);

        // RemoveOrdered keeps oldest-first order. Plain Remove() swaps the last
        // element into the hole, which made "evict oldest" remove the wrong mark.
        while (m_Marks.Count() >= settings.maxMarks && m_Marks.Count() > 0)
        {
            BZ_Spoor oldest = m_Marks.Get(0);
            m_Marks.RemoveOrdered(0);
            if (oldest)
                oldest.DeleteSafe();
        }

        Object obj = GetGame().CreateObjectEx(BZ_Constants.MARK_CLASS, pos, ECE_PLACE_ON_SURFACE | ECE_NOLIFETIME);
        BZ_Spoor mark = BZ_Spoor.Cast(obj);
        if (!mark)
        {
            if (obj)
                obj.DeleteSafe();
            return;
        }

        mark.Arm(settings.lifetimeSeconds, weight, yaw);
        m_Marks.Insert(mark);
    }

    // SurfaceY returns terrain height. Only snap when the player is on the ground,
    // so marks made on a floor upstairs are not buried under the terrain.
    protected vector SnapToGround(vector pos)
    {
        float ground = GetGame().SurfaceY(pos[0], pos[2]);
        if (Math.AbsFloat(pos[1] - ground) < BZ_Constants.GROUND_SNAP_MAX)
            pos[1] = ground;
        return pos;
    }

    protected void AgeMarks(float weatherMul)
    {
        // Iterate backwards: unordered Remove() is safe here
        for (int i = m_Marks.Count() - 1; i >= 0; i--)
        {
            BZ_Spoor mark = m_Marks.Get(i);
            if (!mark)
            {
                m_Marks.Remove(i);
                continue;
            }

            mark.ServerAge(BZ_Constants.TICK_SEC, weatherMul);
            if (mark.GetStage() <= 0)
                m_Marks.Remove(i);
        }
    }
};
