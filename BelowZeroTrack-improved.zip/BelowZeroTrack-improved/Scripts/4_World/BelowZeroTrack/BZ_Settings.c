// JSON keys are unchanged from 0.2.0, so existing settings.json files keep working.
class BZ_Settings
{
    bool  enabled;
    float dropSeconds;
    float lifetimeSeconds;
    float minDistance;
    float windMultiplier;
    float overcastThreshold;
    float stormMultiplier;
    float blizzardMul;
    int   maxMarks;

    void BZ_Settings()
    {
        ResetToDefaults();
    }

    void ResetToDefaults()
    {
        enabled           = true;
        dropSeconds       = BZ_Constants.DEFAULT_DROP_SEC;
        lifetimeSeconds   = BZ_Constants.DEFAULT_LIFE_SEC;
        minDistance       = BZ_Constants.DEFAULT_MIN_DIST;
        windMultiplier    = BZ_Constants.DEFAULT_WIND_MUL;
        overcastThreshold = BZ_Constants.DEFAULT_OVERCAST_T;
        stormMultiplier   = BZ_Constants.DEFAULT_STORM_MUL;
        blizzardMul       = BZ_Constants.DEFAULT_BLIZZARD_MUL;
        maxMarks          = BZ_Constants.DEFAULT_MAX_MARKS;
    }

    // Clamps bad admin values in memory only. The file on disk is never rewritten.
    void Validate()
    {
        dropSeconds       = ClampLogged("dropSeconds", dropSeconds, 0.5, 60.0);
        lifetimeSeconds   = ClampLogged("lifetimeSeconds", lifetimeSeconds, 30.0, 86400.0);
        minDistance       = ClampLogged("minDistance", minDistance, 0.5, 20.0);
        windMultiplier    = ClampLogged("windMultiplier", windMultiplier, 0.0, 20.0);
        overcastThreshold = ClampLogged("overcastThreshold", overcastThreshold, 0.0, 1.0);
        stormMultiplier   = ClampLogged("stormMultiplier", stormMultiplier, 0.0, 20.0);
        blizzardMul       = ClampLogged("blizzardMul", blizzardMul, 0.1, 10.0);
        maxMarks          = ClampIntLogged("maxMarks", maxMarks, 1, 1000);
    }

    protected float ClampLogged(string name, float value, float lo, float hi)
    {
        float clamped = Math.Clamp(value, lo, hi);
        if (clamped != value)
            Print(BZ_Constants.LOG_PREFIX + name + " out of range, using " + clamped.ToString());
        return clamped;
    }

    protected int ClampIntLogged(string name, int value, int lo, int hi)
    {
        int clamped = value;
        if (clamped < lo)
            clamped = lo;
        if (clamped > hi)
            clamped = hi;
        if (clamped != value)
            Print(BZ_Constants.LOG_PREFIX + name + " out of range, using " + clamped.ToString());
        return clamped;
    }
};

class BZ_Config
{
    protected static ref BZ_Settings s_Settings;

    static BZ_Settings Get()
    {
        if (!s_Settings)
            s_Settings = new BZ_Settings();
        return s_Settings;
    }

    static void Load()
    {
        s_Settings = new BZ_Settings();

        if (!FileExist(BZ_Constants.PROFILE_DIR))
            MakeDirectory(BZ_Constants.PROFILE_DIR);

        if (FileExist(BZ_Constants.SETTINGS_PATH))
        {
            // Missing keys keep their defaults. A typo'd file is never overwritten.
            JsonFileLoader<BZ_Settings>.JsonLoadFile(BZ_Constants.SETTINGS_PATH, s_Settings);
        }
        else
        {
            JsonFileLoader<BZ_Settings>.JsonSaveFile(BZ_Constants.SETTINGS_PATH, s_Settings);
        }

        s_Settings.Validate();
        Print(BZ_Constants.LOG_PREFIX + "Settings loaded for " + BZ_Constants.SERVER_NAME);
    }
};
