class BZ_Spoor extends Inventory_Base
{
    protected int   m_Stage;
    protected int   m_Weight;
    protected bool  m_Kicked;
    protected float m_Life;
    protected float m_MaxLife;
    protected float m_Yaw;

    // Client-only FX state
    protected Particle m_Blood;
    protected Particle m_Steam;
    protected bool m_HotSoundPlayed;
    protected int  m_FxStage = -1;
    protected bool m_FxKicked;

    void BZ_Spoor()
    {
        RegisterNetSyncVariableInt("m_Stage", 0, BZ_Constants.STAGE_RIME);
        RegisterNetSyncVariableInt("m_Weight", 0, 3);
        RegisterNetSyncVariableBool("m_Kicked");
        RegisterNetSyncVariableFloat("m_Yaw", 0, 360, 1);
    }

    override void EEInit()
    {
        super.EEInit();
        SetAffectPathgraph(false, false);
        SetScale(0.12);

        // Marks are created with ECE_NOLIFETIME, so the server persists them across
        // restarts. Life is not saved, so a restored mark is an untracked orphan.
        // Arm() runs right after creation; anything still unarmed later is an orphan.
        if (GetGame().IsServer())
            GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(DeleteIfOrphan, BZ_Constants.ORPHAN_CHECK_MS, false);
    }

    protected void DeleteIfOrphan()
    {
        if (m_MaxLife <= 0)
            DeleteSafe();
    }

    override bool IsTakeable() { return false; }
    override bool CanPutInCargo(EntityAI parent) { return false; }
    override bool CanPutIntoHands(EntityAI parent) { return false; }
    override bool IsInventoryVisible() { return false; }

    override void SetActions()
    {
        super.SetActions();
        // IsTakeable() alone still leaves "Pick up" / "Take to hands" in the action wheel
        RemoveAction(ActionTakeItem);
        RemoveAction(ActionTakeItemToHands);
        AddAction(ActionReadBelowZeroSpoor);
        AddAction(ActionKickBelowZeroSpoor);
    }

    protected float NormalizeYaw(float yaw)
    {
        while (yaw < 0)
            yaw = yaw + 360;
        while (yaw >= 360)
            yaw = yaw - 360;
        return yaw;
    }

    void Arm(float lifetime, int weight, float yaw)
    {
        m_MaxLife = lifetime;
        m_Life = lifetime;
        m_Weight = weight;
        m_Yaw = NormalizeYaw(yaw);
        m_Stage = BZ_Constants.STAGE_HOT;
        SetOrientation(Vector(m_Yaw, 0, 0));
        SetSynchDirty();
    }

    protected int ComputeStage()
    {
        if (m_Life <= 0)
            return BZ_Constants.STAGE_GONE;

        float ratio = 1.0;
        if (m_MaxLife > 0)
            ratio = m_Life / m_MaxLife;

        if (ratio > BZ_Constants.HOT_RATIO)
            return BZ_Constants.STAGE_HOT;
        if (ratio > BZ_Constants.GLAZE_RATIO)
            return BZ_Constants.STAGE_GLAZE;
        return BZ_Constants.STAGE_RIME;
    }

    void ServerAge(float dt, float weatherMul)
    {
        if (!GetGame().IsServer())
            return;

        m_Life = m_Life - (dt * weatherMul);

        int stage = ComputeStage();
        if (stage != m_Stage)
        {
            m_Stage = stage;
            SetSynchDirty();
        }

        if (m_Life <= 0)
            DeleteSafe();
    }

    int GetStage() { return m_Stage; }
    bool WasKicked() { return m_Kicked; }

    void KickOver(PlayerBase player)
    {
        if (!GetGame().IsServer())
            return;
        if (m_Stage <= 0 || m_Kicked)
            return;

        m_Kicked = true;

        // Never extend a mark that is already nearly gone
        float kickedLife = m_MaxLife * BZ_Constants.KICK_LIFE_RATIO;
        if (m_Life > kickedLife)
            m_Life = kickedLife;

        m_Stage = ComputeStage();
        SetSynchDirty();

        if (player)
            player.MessageImportant("BELOWZERO — you kicked snow over it. A tracker can still see the scuff.");
    }

    string ReadTheCrust()
    {
        if (m_Kicked)
            return "BELOWZERO — someone kicked snow over this. The scuff is new. They were scared, or smart.";

        string weight = "a thin mark";
        if (m_Weight >= 3)
            weight = "a heavy pour";
        else if (m_Weight == 2)
            weight = "a steady drip";

        if (m_Stage == BZ_Constants.STAGE_HOT)
            return "BELOWZERO — still steaming. " + weight + ". They have not made the next tree line.";
        if (m_Stage == BZ_Constants.STAGE_GLAZE)
            return "BELOWZERO — glass on the crust. " + weight + ". Minutes. The wind has not found it.";
        if (m_Stage == BZ_Constants.STAGE_RIME)
            return "BELOWZERO — frost ate the red. " + weight + ". Look twice or you will walk past them.";
        return "BELOWZERO — the drift has the rest.";
    }

    override void OnVariablesSynchronized()
    {
        super.OnVariablesSynchronized();
        SetOrientation(Vector(m_Yaw, 0, 0));

        // Rebuild particles only when something visible changed
        if (m_Stage != m_FxStage || m_Kicked != m_FxKicked)
        {
            m_FxStage = m_Stage;
            m_FxKicked = m_Kicked;
            ApplyFx();
        }
    }

    override void EEDelete(EntityAI parent)
    {
        StopFx();
        super.EEDelete(parent);
    }

    protected void ApplyFx()
    {
        if (GetGame().IsDedicatedServer())
            return;

        StopFx();
        if (m_Stage <= 0 || m_Kicked)
            return;

        // Blood shows while it is wet. Once frost has eaten the red it stops.
        if (m_Stage == BZ_Constants.STAGE_HOT || m_Stage == BZ_Constants.STAGE_GLAZE)
            m_Blood = Particle.PlayOnObject(ParticleList.BLEEDING_SOURCE, this, "0 0.04 0");

        if (m_Stage == BZ_Constants.STAGE_HOT)
        {
            m_Steam = Particle.PlayOnObject(ParticleList.CAMP_SMALL_SMOKE, this, "0 0.18 0");
            if (!m_HotSoundPlayed)
            {
                m_HotSoundPlayed = true;
                SEffectManager.PlaySoundOnObject(BZ_Constants.SOUND_HOT, this);
            }
        }
    }

    protected void StopFx()
    {
        if (m_Blood)
        {
            m_Blood.Stop();
            m_Blood = null;
        }
        if (m_Steam)
        {
            m_Steam.Stop();
            m_Steam = null;
        }
    }
};

class ActionReadBelowZeroSpoorCB : ActionContinuousBaseCB
{
    override void CreateActionComponent()
    {
        m_ActionData.m_ActionComponent = new CAContinuousTime(1.1);
    }
};

class ActionReadBelowZeroSpoor : ActionContinuousBase
{
    void ActionReadBelowZeroSpoor()
    {
        m_CallbackClass = ActionReadBelowZeroSpoorCB;
        m_CommandUID = DayZPlayerConstants.CMD_ACTIONMOD_PICKUP_HANDS;
        m_StanceMask = DayZPlayerConstants.STANCEMASK_CROUCH | DayZPlayerConstants.STANCEMASK_ERECT;
        m_Text = "Read the crust (BELOWZERO)";
    }

    override void CreateConditionComponents()
    {
        m_ConditionItem = new CCINone;
        m_ConditionTarget = new CCTCursor;
    }

    override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
    {
        if (!player || !target)
            return false;
        BZ_Spoor mark = BZ_Spoor.Cast(target.GetObject());
        return mark && mark.GetStage() > 0;
    }

    override void OnFinishProgressServer(ActionData action_data)
    {
        if (!action_data || !action_data.m_Target || !action_data.m_Player)
            return;
        BZ_Spoor mark = BZ_Spoor.Cast(action_data.m_Target.GetObject());
        if (mark)
            action_data.m_Player.MessageImportant(mark.ReadTheCrust());
    }
};

class ActionKickBelowZeroSpoorCB : ActionContinuousBaseCB
{
    override void CreateActionComponent()
    {
        m_ActionData.m_ActionComponent = new CAContinuousTime(1.8);
    }
};

class ActionKickBelowZeroSpoor : ActionContinuousBase
{
    void ActionKickBelowZeroSpoor()
    {
        m_CallbackClass = ActionKickBelowZeroSpoorCB;
        m_CommandUID = DayZPlayerConstants.CMD_ACTIONMOD_PICKUP_HANDS;
        m_StanceMask = DayZPlayerConstants.STANCEMASK_CROUCH | DayZPlayerConstants.STANCEMASK_ERECT;
        m_Text = "Kick snow over it (BELOWZERO)";
    }

    override void CreateConditionComponents()
    {
        m_ConditionItem = new CCINone;
        m_ConditionTarget = new CCTCursor;
    }

    override bool ActionCondition(PlayerBase player, ActionTarget target, ItemBase item)
    {
        if (!player || !target)
            return false;
        BZ_Spoor mark = BZ_Spoor.Cast(target.GetObject());
        if (!mark || mark.WasKicked() || mark.GetStage() <= 0)
            return false;
        return true;
    }

    override void OnFinishProgressServer(ActionData action_data)
    {
        if (!action_data || !action_data.m_Target)
            return;
        BZ_Spoor mark = BZ_Spoor.Cast(action_data.m_Target.GetObject());
        if (mark)
            mark.KickOver(action_data.m_Player);
    }
};

modded class ActionConstructor
{
    override void RegisterActions(TTypenameArray actions)
    {
        super.RegisterActions(actions);
        actions.Insert(ActionReadBelowZeroSpoor);
        actions.Insert(ActionKickBelowZeroSpoor);
    }
};
