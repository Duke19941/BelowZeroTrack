// Adds BZ_-prefixed state and helpers only. No vanilla method is overridden,
// so this layer should stack cleanly with Syberia / Med Plus / Terje.
modded class PlayerBase
{
    protected ref HumanMovementState m_BZ_MoveState;
    protected vector m_BZ_LastPos;
    protected bool   m_BZ_HasLastPos;
    protected float  m_BZ_Cooldown;

    float BZ_TrackSpacingMul()
    {
        if (IsPlayerInStance(DayZPlayerConstants.STANCEMASK_CROUCH | DayZPlayerConstants.STANCEMASK_RAISEDCROUCH))
            return BZ_Constants.CROUCH_SPACING_MUL;
        return 1.0;
    }

    bool BZ_IsSprinting()
    {
        // Reuse one state object instead of allocating every tick
        if (!m_BZ_MoveState)
            m_BZ_MoveState = new HumanMovementState();

        GetMovementState(m_BZ_MoveState);
        if (m_BZ_MoveState.m_iMovement == DayZPlayerConstants.MOVEMENTIDX_SPRINT)
            return true;

        vector vel = GetVelocity(this);
        return vel.Length() > BZ_Constants.SPRINT_SPEED;
    }

    bool BZ_IsInTransport()
    {
        return GetCommand_Vehicle() != null;
    }

    // Per-player trail state (lives on the player, so it dies with the player)
    float BZ_GetCooldown()
    {
        return m_BZ_Cooldown;
    }

    void BZ_SetCooldown(float value)
    {
        m_BZ_Cooldown = value;
    }

    bool BZ_HasLastPos()
    {
        return m_BZ_HasLastPos;
    }

    vector BZ_GetLastPos()
    {
        return m_BZ_LastPos;
    }

    void BZ_SetLastPos(vector pos)
    {
        m_BZ_LastPos = pos;
        m_BZ_HasLastPos = true;
    }

    void BZ_ClearTrail()
    {
        m_BZ_HasLastPos = false;
    }
};
