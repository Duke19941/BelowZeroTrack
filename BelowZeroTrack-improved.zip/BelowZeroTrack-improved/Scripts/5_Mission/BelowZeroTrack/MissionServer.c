modded class MissionServer
{
    override void OnInit()
    {
        super.OnInit();
        BZ_Config.Load();
        BZ_Manager.Get().Start();
        Print(BZ_Constants.LOG_PREFIX + "Blood trail active");
    }
};
