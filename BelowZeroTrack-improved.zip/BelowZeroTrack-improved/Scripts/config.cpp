class CfgPatches
{
    class BelowZeroTrack_Scripts
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 1.30;
        // BelowZeroTrack_Data first, so BZ_Spoor and the sound set exist before scripts load
        requiredAddons[] = { "DZ_Data", "DZ_Scripts", "BelowZeroTrack_Data" };
    };
};

class CfgMods
{
    class BelowZeroTrack
    {
        dir = "BelowZeroTrack";
        name = "BELOWZERO Crimson Rime";
        version = "0.3.0-1.30exp";
        type = "mod";
        dependencies[] = { "Game", "World", "Mission" };
        class defs
        {
            class gameScriptModule
            {
                files[] = { "BelowZeroTrack/Scripts/3_Game" };
            };
            class worldScriptModule
            {
                files[] = { "BelowZeroTrack/Scripts/4_World" };
            };
            class missionScriptModule
            {
                files[] = { "BelowZeroTrack/Scripts/5_Mission" };
            };
        };
    };
};
